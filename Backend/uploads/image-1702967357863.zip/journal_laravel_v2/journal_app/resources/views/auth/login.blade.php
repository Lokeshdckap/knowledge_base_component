<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Contact Form Template</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        li {
            list-style: none;
        }

        .danger {
            color: red;
        }
    </style>
</head>

<body class>
    
</body>

</html>



{{-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="{{asset('frontend/css/login.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <style>
        li{
            list-style: none;
        }
        .danger{
            color: red;
        }
        .form_container{
            position: relative;
        }
        .forgot{
            position: absolute;
            top: 113px;
            right: 13px;
            text-decoration: none;
            width: 129px;
            color: #111827

        }
    </style>
</head>

<body>
    <!-- <div class="user_alert"></div> -->

    <div class="main_container">
        <div class="logo_container">
            <img src="../images/Logo.svg" alt="" srcset="">
        </div>
        <!-- //toast notification container -->
        <div class="container2">
            <div class="toast">
                <div class="toast-content">
                    <i class="fas fa-solid fa-check check"></i>
                    <div class="message">
                        <span class="text-2"></span>
                    </div>
                </div>
                <i class="fa-solid fa-xmark close"></i>
                <div class="progress"></div>
            </div>

        <div class="container">
            <div class="gif">
                <img src="{{asset('images/welcome/welcome.png')}}" class="gif_welcome" alt="" srcset="" width="500px">

                <a href="{{ url('auth/google') }}"><img src="{{asset('images/welcome/googl.png')}}"  width="200px" class="google" height="45px"></a>
            </div>
            <div class="form_container">
                @if ($errors->any())
                <ul>
                 {!! implode('',$errors->all('<li class="danger">:message</li>'))!!}
                </ul>
                @endif
               <H2 class="welcome_notice">Welcome to DCKAP Palli's Journal <span> &#128075;</span></H2>
               @if (Session::has('error'))
               <div class="alert alert-danger" style="color: red" role="alert">
                  {{ Session::get('error') }}
              </div>
               @endif
                <form action="/authenticate" method="POST">
                    @csrf
                    <div class="form_div">
                        <div class="email_div">
                            <label for="emailId">Email:</label><span class="color">*</span><br>
                            <input class="email" id="emailId" type="email" placeholder="Example@gmail.com"  name="email">
                            @if ($errors->has('email'))
                            <li class="danger">{{$errors->first('email')}}</li>
                            @endif
                        </div>

                       <div class="password_div">
                            <label for="password">Password:</label><span class="color">*</span><br>
                            <input class="password" id="password" type="password" placeholder="Password" name="password">
                            <span class="passicon"><i id="passwordicon" class="fa-solid fa-eye-slash"></i></span>
                            @if ($errors->has('password'))
                            <li class="danger">{{$errors->first('password')}}</li>
                            @endif
                       </div>
                    <button class="loginbtn" type="submit">Login</button>
                </form>
                <div class="forgot">
                    <a href="{{ route('forgot.password.get') }}" class="forgot">Forgot password?</a>
                </div>
                <p class="add-signup">New to Journal's?<a class="add-signup-a" href="/register">signup</a></p>
            </div>
        </div>
    </div>
    <script src="../js/Login.js"></script>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    @if (session('status'))
    <script>
        swal("{{ session('status') }}");
    </script>
    @endif
</body>
</html> --}}
