<?php

namespace App\Http\Livewire;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Login extends Component
{
    public $email;
    public $password;
    public function render()
    {
        return view('livewire.login')->extends('layouts.base');

    }
    public function authenticates(){
        $this->validate([
            'email'=>'required',
            'password'=>'required'
        ]);


        $email = $this->email;
        $password =$this->password;

        if( Auth::attempt(['email' => $email, 'password' => $password])){
            $user = User::where('email',$email)->first();

            Auth::login($user);

            if(Auth::user() && $user->email_verified_at != Null){

                return redirect('/')->with('status','Welcome to the Journals');
             }
            else{
                return redirect('/login')->with('error','Please Verify Your Mail');
            }
        }

        else{
            return back()->withErrors(['Invaild credentials details']);
        }

    }
}
