<div class="lg:flex">
    <div class="lg:w-1/2 xl:max-w-screen-sm">
        <div class="py-6 bg-emerald-600 lg:bg-white flex justify-center lg:justify-start lg:px-10">
            <div>
                <img class="w-24 text-emerald-600" src="{{ asset('images/welcome/2-removebg-preview (1) 1.png') }}"
                    alt="">
            </div>
        </div>
        <div class="mt-4 px-10 sm:px-24 md:px-48 lg:px-10 lg:mt-4 xl:px-24 xl:max-w-2xl">
            <h2
                class="text-center text-4xl text-emerald-950 font-display font-medium lg:text-center xl:text-4xl
                xl:text-bold">
                Log in</h2>
            <div class="mt-12">
                {{-- <form action="/authenticate" method="POST">
                    @csrf --}}
                    <div>
                        <div class="text-sm font-bold text-gray-700 tracking-wide">Email Address</div>
                        <input
                            class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                            type="email" placeholder="mike@gmail.com" name="email" wire:model="email">
                        @if ($errors->has('email'))
                            <li class="danger">{{ $errors->first('email') }}</li>
                        @endif
                    </div>
                    <div class="mt-8">
                        <div class="flex justify-between items-center">
                            <div class="text-sm font-bold text-gray-700 tracking-wide">
                                Password
                            </div>
                            <div>
                                <a href="{{ route('forgot.password.get') }}"
                                    class="text-xs font-display font-semibold text-emerald-600 hover:text-emerald-800
                                    cursor-pointer">
                                    Forgot Password?
                                </a>
                            </div>
                        </div>
                        <input
                            class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                            type="password" placeholder="Enter your password" name="password" wire:model="password">
                        @if ($errors->has('password'))
                            <li class="danger">{{ $errors->first('password') }}</li>
                        @endif

                    </div>
                    <div class="mt-10 flex items-center justify-evenly gap-2">
                        <button wire:click = "authenticates" type="submit"
                            class="bg-emerald-600 text-gray-100 w-2/5 p-4 rounded-full tracking-wide
                            font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                            shadow-lg" style="width:220px">
                            Log In
                        </button>
                        <a href="{{ url('auth/google') }}">
                            <button type="button" data-te-ripple-init data-te-ripple-color="light"
                                class="text-emerald-600 m-auto flex gap-2 items-center bg-white justify-center bg-emerald-600 w-full rounded-full tracking-wide
                                font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                                shadow-lg w-2/5 hover:text-white" style="padding:12px">
                            <img class="h-8 w-8" src="{{asset("images/welcome/google.png")}}" />Sign in with Google
                            </button></a>
                    </div>
                {{-- </form> --}}
                <div class="mt-12 text-sm font-display font-semibold text-gray-700 text-center">
                    Don't have an account ? <a href="/register"
                        class="cursor-pointer hover:underline text-emerald-800 hover:text-emerald-600">Sign
                        up</a>
                </div>
                <div class="flex py-2">
            {{-- <a href="{{ url('auth/google') }}">
            <button type="button" data-te-ripple-init data-te-ripple-color="light"
                        class="m-auto justify-center bg-blue-700  inline-block rounded px-6 py-2.5 text-xs font-medium uppercase leading-normal text-white shadow-md transition duration-150 ease-in-out hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="currentColor"
                            viewBox="0 0 24 24">
                            <path
                                d="M7 11v2.4h3.97c-.16 1.029-1.2 3.02-3.97 3.02-2.39 0-4.34-1.979-4.34-4.42 0-2.44 1.95-4.42 4.34-4.42 1.36 0 2.27.58 2.79 1.08l1.9-1.83c-1.22-1.14-2.8-1.83-4.69-1.83-3.87 0-7 3.13-7 7s3.13 7 7 7c4.04 0 6.721-2.84 6.721-6.84 0-.46-.051-.81-.111-1.16h-6.61zm0 0 17 2h-3v3h-2v-3h-3v-2h3v-3h2v3h3v2z"
                                fill-rule="evenodd" clip-rule="evenodd" />
                        </svg>
                    </button></a> --}}
                </div>
            </div>
        </div>
    </div>

    <div class="w-full h-auto bg-white hidden lg:block lg:w-1/2 bg-cover rounded-l-lg"
        style="background-image: url('{{ asset('images/welcome/Poetry-pana.png') }}')">
    </div>


</div>

</div>
