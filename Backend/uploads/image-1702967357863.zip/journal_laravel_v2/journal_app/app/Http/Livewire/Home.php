<?php

namespace App\Http\Livewire;

use App\Models\Post;
use App\Models\Share;
use App\Models\User;
use Livewire\WithPagination;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;

class Home extends Component
{
    use WithPagination;
    // protected $paginationTheme = 'bootstrap';
    public $sendEmail;

    public $search = "";


    public function render()
    {
          $search = '%'.$this->search.'%';
        if ($this->search) {
            $contents = Post::where('title','like',$search)->paginate(5);
            // dd($contents);
            return view('livewire.home', compact('contents'))
            ->extends('layouts.app');
        } else {
            $contents = Post::where('user_id', Auth::id())->whereNull('deleted_at')->paginate(5);
            return view('livewire.home', compact('contents'))
                ->extends('layouts.app');
        }
    }

    public function starred($id, $value)
    {
        if (Auth::check()) {

            $post_id = $id;

            if (Post::where('id', $post_id)->where('user_id', Auth::id())->exists()) {

                $post = Post::where('id', $post_id)->where('user_id', Auth::id())->first();

                $post->starred = $value;

                $post->update();
            }
        }
    }
    public function remove($id)
    {

        if (Auth::check()) {

            $post_id = $id;

            if (Post::where('id', $post_id)->where('user_id', Auth::id())->exists()) {

                $post = Post::where('id', $post_id)->where('user_id', Auth::id())->first();

                $post->deleted_at = Carbon::now();

                $post->update();
            }
        }
    }


    public function share($id)
    {

        $this->validate([
            'sendEmail' => 'required'
        ]);

        $emailCheck = $this->sendEmail;

        $post_id = $id;

        $email_id = User::where('email', $emailCheck)->first();
        if ($email_id === NULL) {
            Mail::send('auth.shareEmail', ['post_id' => $post_id, 'email_id' => $email_id], function ($message) use ($email_id) {
                $message->to($this->sendEmail);
                $message->subject('DCKAP Journals');
            });
        } else if ($email_id != NULL) {

            $shared_id = User::where('email', $emailCheck)->first()->id;

            // $access = $request->input('access');

            if ($shared_id != Auth::id()) {

                $share = new Share();
                $share->content_id = $post_id;
                $share->user_id = Auth::id();
                $share->share_id = $shared_id;
                // $share->access = $access;

                Mail::send('auth.shareEmail', ['post_id' => $post_id, 'email_id' => $email_id], function ($message) use ($email_id) {
                    $message->to($this->sendEmail);
                    $message->subject('DCKAP Journals');
                });

                $share->save();
            }
        }
    }

    // public function search(){
    //      dd($this->search);
    // }

}
