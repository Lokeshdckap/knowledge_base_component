<div class="lg:flex">
    <div class="lg:w-1/2 xl:max-w-screen-sm">
        <div class="py-6 bg-emerald-600 lg:bg-white flex justify-center lg:justify-start lg:px-10">
            <div>
                <img class="w-24 text-emerald-600" src="<?php echo e(asset('images/welcome/2-removebg-preview (1) 1.png')); ?>"
                    alt="">
            </div>
        </div>
        <div class="mt-4 px-10 sm:px-24 md:px-48 lg:px-10 lg:mt-4 xl:px-24 xl:max-w-2xl">
            <h2
                class="text-center text-4xl text-emerald-950 font-display font-medium lg:text-center xl:text-4xl
                xl:text-bold">
                Log in</h2>
            <div class="mt-12">
                
                    <div>
                        <div class="text-sm font-bold text-gray-700 tracking-wide">Email Address</div>
                        <input
                            class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                            type="email" placeholder="mike@gmail.com" name="email" wire:model="email">
                        <?php if($errors->has('email')): ?>
                            <li class="danger"><?php echo e($errors->first('email')); ?></li>
                        <?php endif; ?>
                    </div>
                    <div class="mt-8">
                        <div class="flex justify-between items-center">
                            <div class="text-sm font-bold text-gray-700 tracking-wide">
                                Password
                            </div>
                            <div>
                                <a href="<?php echo e(route('forgot.password.get')); ?>"
                                    class="text-xs font-display font-semibold text-emerald-600 hover:text-emerald-800
                                    cursor-pointer">
                                    Forgot Password?
                                </a>
                            </div>
                        </div>
                        <input
                            class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                            type="password" placeholder="Enter your password" name="password" wire:model="password">
                        <?php if($errors->has('password')): ?>
                            <li class="danger"><?php echo e($errors->first('password')); ?></li>
                        <?php endif; ?>

                    </div>
                    <div class="mt-10 flex items-center justify-evenly gap-2">
                        <button wire:click = "authenticates" type="submit"
                            class="bg-emerald-600 text-gray-100 w-2/5 p-4 rounded-full tracking-wide
                            font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                            shadow-lg" style="width:220px">
                            Log In
                        </button>
                        <a href="<?php echo e(url('auth/google')); ?>">
                            <button type="button" data-te-ripple-init data-te-ripple-color="light"
                                class="text-emerald-600 m-auto flex gap-2 items-center bg-white justify-center bg-emerald-600 w-full rounded-full tracking-wide
                                font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                                shadow-lg w-2/5 hover:text-white" style="padding:12px">
                            <img class="h-8 w-8" src="<?php echo e(asset("images/welcome/google.png")); ?>" />Sign in with Google
                            </button></a>
                    </div>
                
                <div class="mt-12 text-sm font-display font-semibold text-gray-700 text-center">
                    Don't have an account ? <a href="/register"
                        class="cursor-pointer hover:underline text-emerald-800 hover:text-emerald-600">Sign
                        up</a>
                </div>
                <div class="flex py-2">
            
                </div>
            </div>
        </div>
    </div>

    <div class="w-full h-auto bg-white hidden lg:block lg:w-1/2 bg-cover rounded-l-lg"
        style="background-image: url('<?php echo e(asset('images/welcome/Poetry-pana.png')); ?>')">
    </div>


</div>

</div>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/livewire/login.blade.php ENDPATH**/ ?>