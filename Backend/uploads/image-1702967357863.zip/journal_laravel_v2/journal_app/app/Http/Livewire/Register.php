<?php

namespace App\Http\Livewire;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;
use Illuminate\Support\Str;
class Register extends Component
{

    public $username;
    public $email;
    public $password;
    public $password_confirmation;
    public $token;

    public function render()
    {
        return view('livewire.register')
               ->extends('layouts.base');
    }

    public function register(){
        // dd('ok');

        $this->validate([
            'username'=>'required',
            'email'=>'required|email',
            'password'=>'required|min:8',
            'password_confirmation'=> 'required|same:password|min:8'
          ]);

          $token_vaild = Str::random(64);


          $user = new User;
          $user->name = $this->username;
          $user->email = $this->email;
          $user->remember_token = $token_vaild;
          $user->password = Hash::make($this->password);

          $user->save();

          Mail::send('auth.email.register',['token_vaild'=>$token_vaild],function($message){
              $message->to($this->email);
              $message->subject('Welcome to the Journals');
           });

          Auth::login($user);

        return redirect('email/verify');
    }
}
