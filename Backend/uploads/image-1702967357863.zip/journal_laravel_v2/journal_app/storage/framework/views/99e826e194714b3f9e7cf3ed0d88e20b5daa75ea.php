<div>
    <!-- Include stylesheet -->
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

    <!-- Create the editor container -->
    <div id="<?php echo e($quillId); ?>" wire:ignore></div>

    <!-- Include the Quill library -->
    <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

    <!-- Initialize Quill editor -->
    <script>
        var toolbarOptions = [
            ["image", "video", "link"],
            ['bold', 'italic', 'underline', 'strike'], // toggled buttons
            // ['blockquote', 'code-block'],

            // [{ 'header': 1 }, { 'header': 2 }],               // custom button values
            [{
                'list': 'ordered'
            }, {
                'list': 'bullet'
            }],
            // [{ 'script': 'sub'}, { 'script': 'super' }],      // superscript/subscript
            [{
                'indent': '-1'
            }, {
                'indent': '+1'
            }], // outdent/indent
            // [{ 'size': ['small', false, 'large', 'huge'] }],  // custom dropdown
            [{
                'header': [1, 2, 3, 4, 5, 6, false]
            }],

            [{
                'color': []
            }, {
                'background': []
            }], // dropdown with defaults from theme
            [{
                'font': []
            }],
            [{
                'align': []
            }],
            ["image"]
            ['clean'] // remove formatting button
        ];
        var quill = new Quill('#<?php echo e($quillId); ?>', {
            modules: {
                toolbar: toolbarOptions
            },
            theme: 'snow'
        });
        quill.on('text-change', function() {
            let value = document.getElementsByClassName('ql-editor')[0].innerHTML;
            window.livewire.find('<?php echo e($_instance->id); ?>').set('value', value)
        })
    </script>

    <script>
        addEventListener("trix-blur", function(event) {
            window.livewire.find('<?php echo e($_instance->id); ?>').set('value', trixEditor.getAttribute('value'))
        })
    </script>
</div>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/livewire/quill.blade.php ENDPATH**/ ?>