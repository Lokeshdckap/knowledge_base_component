<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
 <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
 <script src="https://cdn.tailwindcss.com"></script>
 <script src="https://unpkg.com/@themesberg/flowbite@latest/dist/flowbite.bundle.js"></script>
 <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
 <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
<!-- Favicon-->
<link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<script src="https://kit.fontawesome.com/122ac14709.js"crossorigin="anonymous"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/style.css')); ?>">

<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.6/quill.snow.css">
<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.6/quill.core.css">
<script src="https://cdn.jsdelivr.net/npm/quill-image-resize-module@3.0.0/image-resize.min.js"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">


<style>
    .flatpickr-day:hover {
        background: #489f78;
        color: white;
    }

    .flatpickr-day.today:hover {
        background: #489f78;
        color: white;
    }

    .flatpickr-day.today {
        border: 1px solid #489f78;
    }

    .flatpickr-day.selected.startRange, .flatpickr-day.startRange.startRange, .flatpickr-day.endRange.startRange
    {
        background: #489f78;
        -webkit-box-shadow: none;
        box-shadow: none;
        color: #fff;
        border-color: #489f78;
    }
    .flatpickr-day.selected.startRange, .flatpickr-day.startRange.startRange, .flatpickr-day.endRange.endRange
    {
        background: #489f78;
        -webkit-box-shadow: none;
        box-shadow: none;
        color: #fff;
        border-color: #489f78;
    }
    .url{
        background-color: #489f78 !important;
    }


</style>
</head>

<body>
      <?php echo $__env->make('auth.layouts.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main">
       <?php echo $__env->make('auth.layouts.inc.frontnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="<?php echo e(asset('frontend/js/jquery-3.7.0.min.js')); ?>"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

    <script>
          var availableTags = [];

          $.ajax({
            method: 'GET',
            url: '/journal-list',
            success: function (response) {
                startAutoComplete(response)
            }
        })
         function startAutoComplete(availableTags){
          $( "#tags" ).autocomplete({
            source: availableTags
          })
        };
    </script>


    <script src="<?php echo e(asset('frontend/js/custom.js')); ?>" defer></script>
    <script src="<?php echo e(asset('frontend/js/tailwind.config.js')); ?>"></script>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


    <?php if(session('status')): ?>
        <script>
            // swal("<?php echo e(session('status')); ?>");
            let timerInterval
                Swal.fire({
                title: 'Welcome to the DCKAP Journals',
                html: 'I will close in <b></b> milliseconds.',
                timer: 1500,
                timerProgressBar: true,
                didOpen: () => {
                    Swal.showLoading()
                    const b = Swal.getHtmlContainer().querySelector('b')
                    timerInterval = setInterval(() => {
                    b.textContent = Swal.getTimerLeft()
                    }, 100)
                },
                willClose: () => {
                    clearInterval(timerInterval)
                }
                }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                    console.log('I was closed by the timer')
                }
                })
        </script>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        
        
</body>
</html>
<?php /**PATH /home/dckap/Downloads/journal_laravel/journal_app/resources/views/auth/layouts/front.blade.php ENDPATH**/ ?>