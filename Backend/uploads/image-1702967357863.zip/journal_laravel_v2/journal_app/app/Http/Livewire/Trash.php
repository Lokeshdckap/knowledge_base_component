<?php

namespace App\Http\Livewire;

use App\Models\Post;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Trash extends Component
{
    public function render()
    {

        if (Auth::check()) {
            $contents = Post::where('user_id', Auth::id())->whereNotNull('deleted_at')->get();
            return view('livewire.trash', compact('contents'))
                ->extends('layouts.app');
        }
    }

    public function restore($id)
    {

        if (Auth::check()) {

            $post_id = $id;

            if (Post::where('id', $post_id)->where('user_id', Auth::id())->exists()) {

                $post = Post::where('id', $post_id)->where('user_id', Auth::id())->first();

                $post->deleted_at = Null;

                $post->update();
            }
        }
    }

    public function permanentDeleted($id)
    {

        if (Auth::check()) {
            $post_id = $id;

            if (Post::where('id', $post_id)->where('user_id', Auth::id())->exists()) {

                $post = Post::where('id', $post_id)->where('user_id', Auth::id())->first();

                $post->delete();
            }
        }
    }
    public function restoreAll()
    {

        $value = null;
        if (Auth::check()) {

            $post = Post::where('user_id', Auth::id())->whereNotNull('deleted_at')->get();

            foreach ($post as $posts) {

                $posts->deleted_at = $value;

                $posts->update();
            }
        }
    }

    public function emptyTrash(){
        if(Auth::check())
        {
            $post = Post::where('user_id',Auth::id())->whereNotNull('deleted_at')->get();

            foreach($post as $posts){
                $posts->delete();
             }
        }
    }
}
