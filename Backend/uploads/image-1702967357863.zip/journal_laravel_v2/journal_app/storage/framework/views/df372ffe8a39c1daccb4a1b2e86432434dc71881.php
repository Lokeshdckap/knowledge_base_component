<div>
    <main class="mt-16 ml-52">
        <div class="container text-center mx-auto p-4 justify-end">
            <div class="flex justify-end rounded-lg text-lg" role="group">
                <p
                wire:click="toggleView('grid')" id="hide" class="bg-white cursor-pointer view-btn ui-selected rounded-l-lg text-grey-500 hover:bg-emerald-800 hover:text-white border  px-4 py-2 mx-0 outline-none focus:shadow-outline <?php echo e(Request::is('/') ? 'active' : ''); ?>">
                    <i class="fa-solid fa-table-cells"></i>
                </p>

                <p id="btn2"
                wire:click="toggleView('list')"  class="bg-white view-btn cursor-pointer text-grey-500 hover:bg-emerald-800 hover:text-white border border-l-0 rounded-r-lg px-4 py-2 mx-0 outline-none focus:shadow-outline">
                    <i class="fa-solid fa-bars "></i></p>
            </div>
        </div>
    </main>
<div class=" ml-60 mt-0 list-view">
    <div class="m-auto">
        <div>
            <table id="myTable" class="display">
                <thead>
                    <tr>
                        <th>S.no</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Star</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($content->title); ?></td>
                            <td><?php echo Illuminate\Support\str::limit($content->content,50); ?></td>
                            <td>
                                <?php if($content->starred): ?>
                                    <button title="UnStar"><i class="fa-solid fa-star starred-item star"></i></button>
                                <?php else: ?>
                                    <button title="Star"><i
                                            class="fa-regular fa-star starred-item unstar"></i></button>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="close-btn btn-color bg-emerald-700 pt-2 pb-2 pl-4 pr-4 rounded-md"
                                    id="<?php echo e($content->id); ?>">Edit</button>
                                <button
                                    class="close-btn btn-color bg-red-700 pt-2 pb-2 pl-4 pr-4 rounded-md delete-post-item"
                                    id="<?php echo e($content->id); ?>">Delete</button>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/livewire/list.blade.php ENDPATH**/ ?>