const db = require("../../utils/database");
const { Op, where } = require("sequelize");
const { sequelize, col } = require("../../utils/database");

const uuid = require("uuid");


const getTags = (req,res)=>{
    
}



module.exports = {
    getTags
  };

