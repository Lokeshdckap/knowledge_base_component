<style>

:root {
    --clr-primary-1: hsl(14, 100%, 33%, 100%);
    --clr-seconday-color: hsl(0, 0%, 95%, 100%);
    --clr-font-color-1: hsl(209, 28%, 19%, 100);
    --clr-font-color-2: hsl(209, 34%, 28%, 100);
}
body#LoginForm {
        background-color:var(--clr-seconday-color) ;
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        padding: 10px;
    }

.form-heading {
        color: #fff;
        font-size: 23px;
    }

.panel h2 {
        color: #444444;
        font-size: 18px;
        margin: 0 0 8px 0;
    }

.panel p {
        color: #777777;
        font-size: 14px;
        margin-bottom: 30px;
        line-height: 24px;
    }

.login-form .form-control {
        background: #f7f7f7 none repeat scroll 0 0;
        border: 1px solid #d4d4d4;
        border-radius: 4px;
        font-size: 14px;
        height: 50px;
        line-height: 50px;
    }

.main-div {
        background: #ffffff none repeat scroll 0 0;
        border-radius: 2px;
        margin: 10px auto 30px;
        max-width: 38%;
        padding: 50px 70px 70px 71px;
    }

.login-form .form-group {
        margin-bottom: 10px;
    }

.login-form {
        text-align: center;
    }
.forgot a {
        color: #777777;
        font-size: 14px;
        text-decoration: underline;
    }

.login-form .btn.btn-primary {
        background: var(--clr-primary-1) none repeat scroll 0 0;
        color: #ffffff;
        font-size: 14px;
        width: 100%;
        height: 50px;
        line-height: 50px;
        padding: 0;
    }
.forgot {
        text-align: left;
        margin-bottom: 30px;
    }
.botto-text {
        color: #ffffff;
        font-size: 14px;
        margin: auto;
    }
.login-form .btn.btn-primary.reset {
        background: #ff9900 none repeat scroll 0 0;
    }
.back {
        text-align: left;
        margin-top: 10px;
    }
.back a {
        color: #444444;
        font-size: 13px;
        text-decoration: none;
    }
</style>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>

<head>

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->
</head>

<body id="LoginForm">

    <main class="login-form">
        <div class="cotainer">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">Reset Password</div>
                        <div class="card-body">
                            <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger" role="alert">
                               <?php echo e(Session::get('error')); ?>

                           </div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('reset.password.post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="token" value="<?php echo e($token); ?>">
                                <div class="form-group row">
                                    <label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail
                                        Address</label>
                                    <div class="col-md-6">
                                        <input type="text" id="email_address" class="form-control" name="email"
                                            required autofocus>
                                        <?php if($errors->has('email')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="password" class="form-control" name="password"
                                            required autofocus>
                                        <?php if($errors->has('password')): ?>
                                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm
                                        Password</label>
                                    <div class="col-md-6">
                                        <input type="password" id="password-confirm" class="form-control"
                                            name="password_confirmation" required autofocus>
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <span
                                                class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Reset Password
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

</body>

</html>
<?php /**PATH /home/dckap/Downloads/journal_laravel/journal_app/resources/views/auth/forgotPasswordLink.blade.php ENDPATH**/ ?>