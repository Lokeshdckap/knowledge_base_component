<div class="ml-56 mt-20">
    <div class="writing-container mt-8">
        <div class="header flex w-11/12 justify-between items-center m-auto rounded-md">
          <div class="calender">
            <p class="text-center text-xl mb-2">Pick your date</p>
            <div class="relative max-w-sm">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none">
                  <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z"/>
                  </svg>
                </div>
                <input required id="date"  wire:model="date" type="text" class="dateTime rounded-md bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-[220px] pl-10 2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white  focus:outline-none border-none dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Select date">

              </div>
              <?php if($errors->has('date')): ?>
              <li class="danger"><?php echo e($errors->first('date')); ?></li>
            <?php endif; ?>
          </div>
          <div class="container-emojs">
          <p class="text-center text-xl mb-2">How do you feel</p>
            <div class="emojs pl-7 pr-7 pt-2 pb-2 flex gap-5 rounded-md relative">
                <div class="emojsList relative">
                    <p class="emojText absolute top-10" data-tarid="1" wire:ignore>Smile</p>
                    <p class="emoj text-lg"  wire:click = "feelings('&#128517;')" data-tarid="1">&#128517;</p>
                </div>
                <div class="emojsList relative">
                    <p class="emojText absolute top-10" data-tarid="2" wire:ignore>Love</p>
                    <p class="emoj text-lg"   wire:click = "feelings('&#128525;')" data-tarid="2">&#128525;</p>
                </div>
                <div class="emojsList relative">
                    <p class="emojText absolute top-10" data-tarid="3" wire:ignore>Happy</p>
                    <p class="emoj text-lg"   wire:click = "feelings('&#128578;')" data-tarid="3">&#128578;</p>
                </div>
                <div class="emojsList relative">
                    <p class="emojText absolute top-10" data-tarid="4" wire:ignore>Cry</p>
                    <p class="emoj text-lg"   wire:click = "feelings('&#128560;')" data-tarid="4">&#128560;</p>
                </div>
                <div class="emojsList relative">
                    <p class="emojText absolute top-10" data-tarid="5" wire:ignore>Angry</p>
                    <p class="emoj text-lg"  wire:click = "feelings('&#128545;')" data-tarid="5">&#128545;</p>
                </div>
            </div>

            <?php if($errors->has('feel')): ?>
            
            <div id="toast-danger" class="flex items-center w-full max-w-xs p-4 mb-4 text-gray-500 bg-white rounded-lg shadow dark:text-gray-400 dark:bg-gray-800" role="alert">
                <div class="inline-flex items-center justify-center flex-shrink-0 w-8 h-8 text-red-500 bg-red-100 rounded-lg dark:bg-red-800 dark:text-red-200">
                    <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 11.793a1 1 0 1 1-1.414 1.414L10 11.414l-2.293 2.293a1 1 0 0 1-1.414-1.414L8.586 10 6.293 7.707a1 1 0 0 1 1.414-1.414L10 8.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 10l2.293 2.293Z"/>
                    </svg>
                    <span class="sr-only">Error icon</span>
                </div>
                <div class="ml-3 text-sm font-normal"><?php echo e($errors->first('feel')); ?></div>
                <button type="button" class="ml-auto -mx-1.5 -my-1.5 bg-white text-gray-400 hover:text-gray-900 rounded-lg focus:ring-2 focus:ring-gray-300 p-1.5 hover:bg-gray-100 inline-flex items-center justify-center h-8 w-8 dark:text-gray-500 dark:hover:text-white dark:bg-gray-800 dark:hover:bg-gray-700" data-dismiss-target="#toast-danger" aria-label="Close">
                    <span class="sr-only">Close</span>
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                </button>
            </div>
          <?php endif; ?>
          </div>
        </div>
        <div class="title text-center mt-4 mb-6">

            <input type="text" class="rounded-md userTitle text-center shadow-md border-0 outline-none bg-white" id="userTitle" wire:model.lazy="title"  placeholder="Title....." />
            <?php if($errors->has('title')): ?>
            <li class="danger"><?php echo e($errors->first('title')); ?></li>
            <?php endif; ?>
        </div>
        <div class="text-editor w-11/12 m-auto">
            <?php if($errors->has('body')): ?>
            <li class="danger"><?php echo e($errors->first('body')); ?></li>
          <?php endif; ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('quill')->html();
} elseif ($_instance->childHasBeenRendered('l3861793029-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3861793029-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3861793029-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3861793029-0');
} else {
    $response = \Livewire\Livewire::mount('quill');
    $html = $response->html();
    $_instance->logRenderedChild('l3861793029-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          <div class="subBtn pt-5 text-end">
              <button class="pl-7 pr-7 pt-2 bg-emerald-600 text-white hover:bg-emerald-800  pb-2 rounded-md" wire:click ="Writingstore">Publish</button>
          </div>
        </div>
    </div>
    </div>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/livewire/writing.blade.php ENDPATH**/ ?>