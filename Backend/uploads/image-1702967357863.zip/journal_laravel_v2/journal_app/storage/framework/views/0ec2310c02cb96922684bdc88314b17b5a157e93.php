<div class="ml-60 mt-24">
    <div class="carts flex flex-row gap-5 m-auto">
        <?php if($contents->count() > 0): ?>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class=" w-80 mt-2 bg-white border border-gray-200 product ronded-md    ">
                    <a href="#">
                        <h5 class="text-center mt-2 mb-2 text-2xl font-bold tracking-tight text-gray-900">
                            <?php echo e($content->title); ?></h5>
                    </a>
                    <p class="h-24 show-view overflow-hidden	m-auto text-justify w-64 mb-3 font-normal text-gray-700 dark:text-gray-400 content"
                        id="<?php echo e($content->id); ?>">
                        <?php echo e(Illuminate\Support\str::limit(strip_tags($content->content),150)); ?></p>
                    <input type="hidden" class="post_id" value="<?php echo e($content->id); ?>">
                    <div class="p-5 flex justify-between relative">
                        <div class="date">
                            <a href="#"
                                class="text-xs inline-flex items-cente,r px-3 py-2 text-sm font-medium text-center text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                <?php echo e(\Carbon\Carbon::parse($content->from_date)->format('d/m/Y')); ?> -
                                <?php echo e(\Carbon\Carbon::parse($content->end_date)->format('d/m/Y')); ?>


                            </a>
                        </div>
                        <div class="action-btns items-center">
                            <?php if($content->starred): ?>
                                <button type="submit" wire:click="starred(<?php echo e($content->id); ?>,0)"><i
                                        class="fa-solid fa-star starred-item star"></i></button>
                            <?php endif; ?>
                            <button type="submit" wire:click="remove(<?php echo e($content->id); ?>)"><i
                                    class="fa-solid fa-trash delete-post-item"></i></button>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="w-full ml-80 m-auto">
                <img src="<?php echo e(asset('images/welcome/starred.svg')); ?>" class="h-80" alt="" srcset="">
                <p class="mt-7 ml-24">No Starred Items here..</p>
            </div>
        <?php endif; ?>
    </div>
    <div class="blackScreen de-active"></div>
    <div tabindex="-1" class="fixed view-user-contents de-active top-0 left-0 right-0 z-50  w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full bg-gray-300">
        <div class="relative w-full max-w-7xl max-h-full">
            <!-- Modal content -->
            <div class="relative flex justify-between bg-white shadow dark:bg-gray-700 w-full">
                <!-- Modal header -->
                <div class="view-containers p-5 dark:border-gray-600 w-4/5">
                    <h3 class="text-xl ml-10 font-medium text-gray-900 dark:text-white title">

                    </h3>
                    <div class="p-6 space-y-6 w-11/12">
                        <p class="text-base h-full overflow-scroll overflow-x-hidden overflow-y-hidden leading-relaxed text-gray-500 dark:text-gray-400 fullContent">
                        </p>
                    </div>

                </div>
                <!-- Modal body -->
                <div class="flex flex-col">
                    <button type="button" class="close-view mt-2.5 mr-2.5 text-gray-400 bg-transparent hover:bg-red-800 hover:text-white rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white" data-modal-hide="extralarge-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                   <div class="emptyLine ml-80"></div>
                    <div class="map-view p-6 border-gray-600">
                        <img src="<?php echo e(asset('images/welcome/Frame 8493.svg')); ?>" h-72 w-60/>
                        <div class="details flex flex-col gap-5 mt-5">

                        <div class="location flex gap-3">
                            <div>
                                <i class="fa-solid fa-location-dot"></i>
                            </div>
                            <div>
                                <p>Location</p>
                                <p>Anna Nagar, Chennai</p>
                            </div>
                        </div>
                        <div class="location flex gap-3">
                            <div>
                                <i class="fa-regular fa-clock"></i>
                            </div>
                            <div>
                                <p>Data/Time</p>
                                <p>11.10 AM GMT +05:30, Sat, Aug 05,2023</p>
                            </div>
                        </div>
                        <div class="location flex gap-3">
                            <div>
                                <i class="fa-regular fa-calendar-days"></i>
                            </div>
                            <div>
                                <p>On this day, Aug 05</p>
                                <p>1 Entry, 0 Photos, 1year</p>
                            </div>
                        </div>
                        <div class="location flex gap-3">
                            <div>
                                <i class="fa-regular fa-calendar-days"></i>
                            </div>
                            <div>
                                <p>On this day,  WednesdayAug 05</p>
                                <p>1 Entry, 0 Photos, 1year </p>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <div class="flex bg-white items-center justify-between p-6 space-x-2">
                <div class="action-btns">
                    <button data-modal-hide="extralarge-modal" type="button" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Edit</button>
                    <button data-modal-hide="extralarge-modal" type="button" class="text-white bg-red-700 hover:bg-red-950 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-white focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">Trash</button>
                </div>
                <div class="expBtn">
                    <button data-modal-hide="extralarge-modal" type="button" class="text-white bg-red-700 hover:bg-red-950 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-white focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600" id="downloadBtn">Export</button>
                </div>
            </div>
        </div>
</div>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/livewire/starred.blade.php ENDPATH**/ ?>