@extends('auth.layouts.front')

@section('title')
    Welcome to our Journals!
@endsection

@section('content')

@endsection
