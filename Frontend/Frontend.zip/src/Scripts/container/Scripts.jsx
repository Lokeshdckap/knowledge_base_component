import React from 'react'
import { ScriptComponents } from '../components/ScriptComponents'

export const Scripts = () => {


  
  return (
    <>
        <ScriptComponents />
    </>
  )
}
