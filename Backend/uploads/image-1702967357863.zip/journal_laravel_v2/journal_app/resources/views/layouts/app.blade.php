<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title')</title>
 <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
 <script src="https://cdn.tailwindcss.com"></script>
 <script src="https://unpkg.com/@themesberg/flowbite@latest/dist/flowbite.bundle.js"></script>
 <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
 <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet" />
<!-- Favicon-->
<link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
<script src="https://kit.fontawesome.com/122ac14709.js"crossorigin="anonymous"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="{{asset('frontend/css/style.css')}}">

<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.6/quill.snow.css">
<link rel="stylesheet" href="https://cdn.quilljs.com/1.3.6/quill.core.css">
<script src="https://cdn.jsdelivr.net/npm/quill-image-resize-module@3.0.0/image-resize.min.js"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.0/flowbite.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
@livewireStyles
    <!-- datatable css link -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />
    <!-- jquery cdn link -->
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
        crossorigin="anonymous"></script>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.css" rel="stylesheet" />

    <link href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>

    <!-- tailwind css -->
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.tailwindcss.min.css"> -->
    <style>
        #selectable-1 .ui-selected {
            background: #1f4636;
            color: white;
        }

        .active {

            background: #27634a !important;
            color: rgb(241, 236, 236);
        }

        .dataTables_wrapper {
            width: 95%;
            margin: auto
        }


        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
            margin: 0;
            padding: 0;
            width: 100%;
            table-layout: fixed;
        }

        table th {
            background: #04AA6D;
            color: white;
        }

        table tr {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            padding: .35em;
        }

        table th,
        table td {
            padding: .625em;
        }

        table th {
            font-size: .85em;
            letter-spacing: .1em;
            text-transform: uppercase;
            text-align: left;
        }


        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #04AA6D !important;
            color: white !important;
            border: none !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: #04AA6D !important;
            color: white !important;
            padding: 0.5em 1em;

        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: none !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #04AA6D;
            color: white !important;
        }

        .dataTables_wrapper .dataTables_length select {
            outline: none;
            border: 1px solid #aaa;
            border-radius: 3px;
            padding: 5px;
            background-color: transparent;
            color: inherit;
            padding: 4px;
        }


        .dataTables_wrapper .dataTables_length {
            padding: 10px;
        }

        .dataTables_wrapper .dataTables_filter {
            padding: 10px;

        }

        .dataTables_wrapper .dataTables_length select {
            outline: none;
            border: 1px solid #aaa;
            border-radius: 3px;
            padding: 5px;
            background-color: transparent;
            color: inherit;
            padding-right: 20px;
        }

        .dataTables_wrapper .dataTables_filter input {
            outline: none;
        }
        .flatpickr-day:hover {
        background: #489f78;
        color: white;
    }

    .flatpickr-day.today:hover {
        background: #489f78;
        color: white;
    }

    .flatpickr-day.today {
        border: 1px solid #489f78;
    }

    .flatpickr-day.selected.startRange, .flatpickr-day.startRange.startRange, .flatpickr-day.endRange.startRange
    {
        background: #489f78;
        -webkit-box-shadow: none;
        box-shadow: none;
        color: #fff;
        border-color: #489f78;
    }
    .flatpickr-day.selected.startRange, .flatpickr-day.startRange.startRange, .flatpickr-day.endRange.endRange
    {
        background: #489f78;
        -webkit-box-shadow: none;
        box-shadow: none;
        color: #fff;
        border-color: #489f78;
    }
    .url{
        background-color: #489f78 !important;
    }
    li{
        list-style: none;
        color: red
    }
    </style>
</head>
<body>

      @include('auth.layouts.inc.sidebar')
    <div class="main">

       @include('auth.layouts.inc.frontnav')

      @yield('content')
    </div>
@livewireScripts
<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

<script src="{{ asset('frontend/js/custom.js') }}" defer></script>
<script src="{{ asset('frontend/js/tailwind.config.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>


</body>

</html>




