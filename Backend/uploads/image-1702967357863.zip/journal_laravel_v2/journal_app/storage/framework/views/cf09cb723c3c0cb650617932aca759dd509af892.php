<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Contact Form Template</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        li {
            list-style: none;
        }

        .danger {
            color: red;
        }
    </style>
</head>

<body class>
    <div class="lg:flex">
        <div class="lg:w-1/2 xl:max-w-screen-sm">
            <div class="py-6 bg-emerald-600 lg:bg-white flex justify-center lg:justify-start lg:px-10">
                <div>
                    <img class="w-24 text-emerald-600" src="<?php echo e(asset('images/welcome/2-removebg-preview (1) 1.png')); ?>"
                        alt="">
                </div>
            </div>
            <div class="mt-4 px-10 sm:px-24 md:px-48 lg:px-10 lg:mt-4 xl:px-24 xl:max-w-2xl">
                <h2
                    class="text-center text-4xl text-emerald-950 font-display font-medium lg:text-center xl:text-4xl
                    xl:text-bold">
                    Log in</h2>
                <div class="mt-12">
                    <form action="/authenticate" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <div class="text-sm font-bold text-gray-700 tracking-wide">Email Address</div>
                            <input
                                class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                                type="email" placeholder="mike@gmail.com" name="email">
                            <?php if($errors->has('email')): ?>
                                <li class="danger"><?php echo e($errors->first('email')); ?></li>
                            <?php endif; ?>
                        </div>
                        <div class="mt-8">
                            <div class="flex justify-between items-center">
                                <div class="text-sm font-bold text-gray-700 tracking-wide">
                                    Password
                                </div>
                                <div>
                                    <a href="<?php echo e(route('forgot.password.get')); ?>"
                                        class="text-xs font-display font-semibold text-emerald-600 hover:text-emerald-800
                                        cursor-pointer">
                                        Forgot Password?
                                    </a>
                                </div>
                            </div>
                            <input
                                class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-600"
                                type="password" placeholder="Enter your password" name="password">
                            <?php if($errors->has('password')): ?>
                                <li class="danger"><?php echo e($errors->first('password')); ?></li>
                            <?php endif; ?>

                        </div>
                        <div class="mt-10">
                            <button type="submit"
                                class="bg-emerald-600 text-gray-100 p-4 w-full rounded-full tracking-wide
                                font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                                shadow-lg">
                                Log In
                            </button>
                        </div>
                    </form>
                    <div class="mt-12 text-sm font-display font-semibold text-gray-700 text-center">
                        Don't have an account ? <a href="/register"
                            class="cursor-pointer hover:underline text-emerald-800 hover:text-emerald-600">Sign
                            up</a>
                    </div>
                    <div class="flex py-2">
                
                    </div>
                </div>
            </div>
        </div>

        <div class="w-full h-auto bg-white hidden lg:block lg:w-1/2 bg-cover rounded-l-lg"
            style="background-image: url('<?php echo e(asset('images/welcome/Poetry-pana.png')); ?>')">
        </div>


    </div>

    </div>
</body>

</html>




<?php /**PATH /home/dckap/Downloads/journal_laravel/journal_app/resources/views/auth/login.blade.php ENDPATH**/ ?>