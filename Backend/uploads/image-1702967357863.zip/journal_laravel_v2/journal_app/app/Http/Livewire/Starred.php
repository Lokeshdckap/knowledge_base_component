<?php

namespace App\Http\Livewire;

use App\Models\Post;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;

class Starred extends Component
{


    public function render()
    {

        if(Auth::check())
        {
        $contents = Post::where('user_id',Auth::id())->whereNull('deleted_at')->where('starred',1)->get();
        return view('livewire.starred',compact('contents'))
        ->extends('layouts.app');
        }
    }
        public function starred($id,$value){

            if(Auth::check()){

                $post_id = $id;

                if(Post::where('id',$post_id)->where('user_id',Auth::id())->exists())
                {

                   $post = Post::where('id',$post_id)->where('user_id',Auth::id())->first();

                   $post->starred = $value;

                   $post->update();

            }
        }

        }

        public function remove($id)
        {

         if(Auth::check()){

            $post_id = $id;

          if(Post::where('id',$post_id)->where('user_id',Auth::id())->exists()){

             $post = Post::where('id',$post_id)->where('user_id',Auth::id())->first();

             $post->deleted_at = Carbon::now();

             $post->update();
          }
         }
        }

    }
