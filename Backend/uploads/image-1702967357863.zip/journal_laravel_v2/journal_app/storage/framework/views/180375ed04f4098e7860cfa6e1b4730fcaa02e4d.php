<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Contact Form Template</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        li {
            list-style: none;
        }

        .danger {
            color: red;
        }
    </style>
</head>

<body class>
    <div class="lg:flex">
        <div class="lg:w-1/2 xl:max-w-screen-sm">
            <div class="pt-6 pb-2.5 bg-emerald-100 lg:bg-white flex justify-center lg:justify-start lg:px-10">
                <div class="cursor-pointer flex items-center">
                    <div>
                        <img class="w-24 text-emerald-600" src="<?php echo e(asset('images/welcome/2-removebg-preview (1) 1.png')); ?>"
                            alt="">
                    </div>
                </div>
            </div>
            <div class=" px-10 sm:px-24 md:px-48 lg:px-10  xl:px-24 xl:max-w-2xl">
                <h2 class="text-center text-2xl text-emerald-950 font-display font-medium lg:text-center xl:text-4xl">
                    Sign In</h2>
                <div class="mt-6">
                    <form action="/store" method="POST">
                        <?php echo csrf_field(); ?>
                        <div>
                            <div class=" text-sm font-bold text-gray-700 tracking-wide">
                                User Name

                            </div>
                            <input
                                class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-500"
                                type="text" placeholder="User Name" name="username">
                            <?php if($errors->has('username')): ?>
                                <li class="danger"><?php echo e($errors->first('username')); ?></li>
                            <?php endif; ?>
                        </div>
                        <div class=" text-sm font-bold text-gray-700 tracking-wide mt-3">
                            Email

                        </div>
                        <input
                            class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-500"
                            type="email" placeholder="ex.journal@gmail.com" name="email">
                        <?php if($errors->has('email')): ?>
                            <li class="danger"><?php echo e($errors->first('email')); ?></li>
                        <?php endif; ?>

                        <div>
                            <div class="text-sm font-bold text-gray-700 tracking-wide mt-3">Password </div>
                            <input
                                class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-500"
                                type="password" placeholder="password" name="password">
                            <?php if($errors->has('password')): ?>
                                <li class="danger"><?php echo e($errors->first('password')); ?></li>
                            <?php endif; ?>
                        </div>

                        <div>
                            <div class="text-sm font-bold text-gray-700 tracking-wide mt-3">Confirm Password</div>
                            <input
                                class="w-full text-lg py-2 border-b border-gray-300 focus:outline-none focus:border-emerald-500"
                                type="password" placeholder="confirm password" name="password_confirmation">
                            <?php if($errors->has('password_confirmation')): ?>
                                <li class="danger"><?php echo e($errors->first('password_confirmation')); ?></li>
                            <?php endif; ?>
                        </div>
                        <div class="mt-4">
                            <button type="submit"
                                class="bg-emerald-600 h-12 text-white p-4 w-full rounded-full tracking-wide
                                font-semibold font-display focus:outline-none focus:shadow-outline hover:bg-emerald-800
                                shadow-lg">
                                Sign up
                            </button>
                        </div>
                    </form>
                    <div class="mt-4  text-sm font-display font-semibold text-gray-700 text-center">
                        Already have an account ? <a href="/login"
                            class="cursor-pointer text-emerald-800 no-underline hover:underline hover:text-emerald-600">Log
                            in</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="w-full h-auto bg-white hidden lg:block lg:w-1/2 bg-cover rounded-l-lg"
            style="background-image: url('<?php echo e(asset('images/welcome/Poetry-pana.png')); ?>')">
        </div>
    </div>
</body>

</html>



























<?php /**PATH /home/dckap/Downloads/journal_laravel/journal_app/resources/views/auth/register.blade.php ENDPATH**/ ?>