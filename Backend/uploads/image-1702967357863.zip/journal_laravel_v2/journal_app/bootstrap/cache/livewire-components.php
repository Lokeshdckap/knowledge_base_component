<?php return array (
  'home' => 'App\\Http\\Livewire\\Home',
  'login' => 'App\\Http\\Livewire\\Login',
  'quill' => 'App\\Http\\Livewire\\Quill',
  'register' => 'App\\Http\\Livewire\\Register',
  'starred' => 'App\\Http\\Livewire\\Starred',
  'toggle' => 'App\\Http\\Livewire\\Toggle',
  'trash' => 'App\\Http\\Livewire\\Trash',
  'writing' => 'App\\Http\\Livewire\\Writing',
);