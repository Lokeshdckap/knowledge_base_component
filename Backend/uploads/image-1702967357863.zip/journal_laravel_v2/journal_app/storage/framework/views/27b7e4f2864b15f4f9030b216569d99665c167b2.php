<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- datatable css link -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.css" />
    <!-- jquery cdn link -->
    <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM="
        crossorigin="anonymous"></script>

    <!-- tailwind css -->
    <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.tailwindcss.min.css"> -->
    <style>
        .dataTables_wrapper {
            width: 95%;
        }


        table {
            border: 1px solid #ccc;
            border-collapse: collapse;
            margin: 0;
            padding: 0;
            width: 100%;
            table-layout: fixed;
        }

        table th {
            background: #04AA6D;
            color: white;
        }

        table tr {
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            padding: .35em;
        }

        table th,
        table td {
            padding: .625em;
        }

        table th {
            font-size: .85em;
            letter-spacing: .1em;
            text-transform: uppercase;
            text-align: left;
        }


        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: #04AA6D !important;
            color: white !important;
            border: none !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button.current:hover {
            background: #04AA6D !important;
            color: white !important;
            padding: 0.5em 1em;

        }

        .dataTables_wrapper .dataTables_paginate .paginate_button {
            border: none !important;
        }

        .dataTables_wrapper .dataTables_paginate .paginate_button:hover {
            background: #04AA6D;
            color: white !important;
        }

        .dataTables_wrapper .dataTables_length select {
            outline: none;
            border: 1px solid #aaa;
            border-radius: 3px;
            padding: 5px;
            background-color: transparent;
            color: inherit;
            padding: 4px;
        }


        .dataTables_wrapper .dataTables_length {
            padding: 10px;
        }

        .dataTables_wrapper .dataTables_filter {
            padding: 10px;

        }

        .dataTables_wrapper .dataTables_length select {
            outline: none;
            border: 1px solid #aaa;
            border-radius: 3px;
            padding: 5px;
            background-color: transparent;
            color: inherit;
            padding-right: 20px;
        }

        .dataTables_wrapper .dataTables_filter input {
            outline: none;
        }
    </style>
</head>
<?php $__env->startSection('content'); ?>
<main class="mt-16 ml-52">
    <div class="container text-center mx-auto p-4 justify-end">
      <div class="flex justify-end rounded-lg text-lg" role="group">
        
          <a href="/"><button
          class="bg-white text-grey-500 hover:bg-emerald-800 hover:text-white border border-l-0 rounded-r-lg px-4 py-2 mx-0 outline-none focus:shadow-outline <?php echo e(Request::is('/') ? 'bg-emerald-800' : ''); ?>"><i class="fa-solid fa-table-cells"></i></button></a>
          <a href="/list"><button
          class="bg-white text-grey-500 hover:bg-emerald-800 hover:text-white border  px-4 py-2 mx-0 outline-none focus:shadow-outline"><i class="fa-solid fa-bars"></i></button></a>

      </div>
    </div>
</main>
    <div class="flex flex-row ml-60 mt-0">
        <div class="m-auto">
            <div>
                <table id="myTable" class="display">
                    <thead>
                        <tr>
                            <th>S.no</th>
                            <th>Title</th>
                            <th>Date</th>
                            <th>Star</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><?php echo e($content->title); ?></td>
                                <td><?php echo Illuminate\Support\str::limit($content->content, 100); ?></td>
                                <td>
                                    <?php if($content->starred): ?>
                                        <button title="UnStar"><i class="fa-solid fa-star starred-item star"></i></button>
                                    <?php else: ?>
                                        <button title="Star"><i
                                                class="fa-regular fa-star starred-item unstar"></i></button>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button
                                        class="close-btn btn-color bg-emerald-700 pt-2 pb-2 pl-4 pr-4 rounded-md" id="<?php echo e($content->id); ?>">Edit</button>
                                    <button
                                        class="close-btn btn-color bg-red-700 pt-2 pb-2 pl-4 pr-4 rounded-md delete-post-item"  id="<?php echo e($content->id); ?>">Delete</button>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- datatable js link -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.js"></script>
    <!-- tailwind css -->
    <!-- <script src="https://cdn.tailwindcss.com/3.3.3"></script> -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    
    <script>
        $('#myTable').DataTable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dckap/Downloads/journal_laravel/journal_app/resources/views/frontend/list.blade.php ENDPATH**/ ?>