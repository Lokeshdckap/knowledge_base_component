<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Contact Form Template</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        li {
            list-style: none;
        }

        .danger {
            color: red;
        }
    </style>
</head>

<body class>
   
</body>

</html>


























{{--
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="{{asset('frontend/css/register.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
        li{
            list-style: none;
        }
        .danger{
            color: red;
        }
    </style>
</head>

<body>

    <div class="main_container">
        <div class="logo_container">
            <img src="../images/Logo.svg" alt="" srcset="">
        </div>
        <div class="container">
            <div class="toast">
                <div class="toast-content">
                    <i class="fa-solid fa-xmark check"></i>
                    <div class="message">
                        <span class="text text-2"></span>
                    </div>
                </div>
                <i class="fa-solid fa-xmark close"></i>
                <div class="progress"></div>
            </div>
            <div class="gif">
                <img src="{{asset('images/welcome/welcome.svg')}}" class="gif_welcome" alt="" srcset="">
                <div class="sign-btn">
                <form action="/registrationLogic" method="post">
                </form>
                </div>
            </div>
            <div class="form_container">
                @if (Session::has('message'))
                <div class="alert alert-success" style="color: green" role="alert">
                   {{ Session::get('message') }}
               </div>
               @endif
               @if (Session::has('error'))
               <div class="alert alert-danger" style="color: red" role="alert">
                  {{ Session::get('error') }}
              </div>
               @endif
               <H2 class="welcome_notice">Welcome to DCKAP Palli's Journal <span>👋</span></H2>
                <form action="/store" method="POST">
                    @csrf
                    <div class="form_div">
                        <div class="name_div">
                            <label for="your-name">Your name:</label><span class="color">*</span><br>
                            <input class="yourname" id="your-name"type="text" name="username" placeholder="Enter your Name">
                            @if ($errors->has('username'))
                            <li class="danger">{{$errors->first('username')}}</li>
                            @endif
                        </div>
                       <div>
                        <label for="emailId">Email:</label><span class="color">*</span><br>
                        <input class="email" id="emailId" name="email" type="email" placeholder="Example@gmail.com"><br><br>
                        @if ($errors->has('email'))
                        <li class="danger">{{$errors->first('email')}}</li>
                        @endif
                       </div>

                       <div>
                        <label for="password">Password:</label><span class="color">*</span><br>
                        <input class="password" id="password" name="password" type="password" placeholder="Password">
                        <span class="passicon"><i id="passwordicon" class="fa-solid fa-eye-slash"></i></span>
                        @if ($errors->has('password'))
                        <li class="danger">{{$errors->first('password')}}</li>
                        @endif
                        <br><br>
                       </div>

                       <div>
                        <label for="conform-password">Confirm Password:</label><span class="color">*</span><br>
                        <p class="Password_alert"></p>
                        <input class="confirmpassword" name="password_confirmation" id="conform-password" type="password" placeholder="Confirm password">
                        <span class="passicon"><i id="passwordicon" class="fa-solid fa-eye-slash"></i></span>
                        @if ($errors->has('password_confirmation'))
                        <li class="danger">{{$errors->first('password_confirmation')}}</li>
                        @endif
                        <br><br>
                       </div>

                        <button class="signbtn" type="submit">Sign Up </button>
                        <p class="add-login">Already have an Account?<a class="add-login-a" href="/login">Login Here</a></p>
                </form>
            </div>
        </div>
    </div>
    <script type="module" src="../js/signup.js"></script>
</body>

</html> --}}
