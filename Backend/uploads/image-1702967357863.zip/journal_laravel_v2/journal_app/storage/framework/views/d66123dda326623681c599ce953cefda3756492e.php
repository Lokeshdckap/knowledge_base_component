<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>DCKAP Journals</title>
    <script src="https://cdn.tailwindcss.com"></script>
    
    <style>
        li {
            list-style: none;
        }

        .danger {
            color: red;
        }

    </style>
      <?php echo \Livewire\Livewire::styles(); ?>

      
</head>

<body>
    
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>


    
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top',
            showConfirmButton: false,
            showCloseButton: true,
            timer: 5000,
            timerProgressBar:true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        window.addEventListener('alert',({detail:{type,message}})=>{
            Toast.fire({
                icon:type,
                title:message
            })
        })
    </script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script type="module">
        import hotwiredTurbo from 'https://cdn.skypack.dev/@hotwired/turbo';
    </script>
    <script src="https://cdn.jsdelivr.net/gh/livewire/turbolinks@v0.1.x/dist/livewire-turbolinks.js" data-turbolinks-eval="false" data-turbo-eval="false"></script>
</body>
</html>
<?php /**PATH /home/dckap/Downloads/view_Content/journal_laravel_v2/journal_app/resources/views/layouts/base.blade.php ENDPATH**/ ?>