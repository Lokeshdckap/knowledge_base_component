<?php

namespace App\Http\Livewire;

use App\Models\Post;
use Illuminate\Support\Facades\Auth;
use IntlChar;
use Livewire\Component;

class Writing extends Component
{
    public $date;
    public $feel;
    public $title;
    public $body;




    public $listeners = [
        Quill::EVENT_VALUE_UPDATED
    ];

    public function quill_value_updated($value){
        $this->body = $value;
    }

    public function render()
    {
        return view('livewire.writing')->extends('layouts.app');
    }

    public function Writingstore(){

        $this->validate([
            'date'=>'required',
            'title'=>'required',
            'feel'=>'required',
            'body'=> 'required'
          ]);

        $content = new Post;
        $content->title = $this->title;
        $content->emoji = $this->feel;
        $content->from_date =substr($this->date,0,10);
        $content->end_date =substr($this->date,-10);
        $content->content = $this->body;
        $content->user_id = Auth::id();

        $content->save();
        // dd(substr($this->date,0,10));
        // dd(substr($this->date,-10));
         return redirect()->to('/');
    }

    public function feelings($feel){

        $this->feel = sprintf('%X', IntlChar::ord($feel));

        // dd($this->feel);


    }
}
